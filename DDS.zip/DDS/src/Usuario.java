
public class Usuario {

	public Mapa unMapa;
	
	public boolean esAdministrador()
	{
		return false;
	}
}

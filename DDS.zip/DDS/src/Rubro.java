
public class Rubro {
	public String nombre;
	
	/*
	 * SETs y GETs
	 */
	
	public void setNombre(String nom) {
		this.nombre = nom;
	}
	
	/*
	 * compararCercania();
	 * Detalle: Dado un POI y una Interface, te decie si esta cerca o no.
	 * 
	 */
	public boolean compararCercania(Poi unPoi, Interface unaInterface) {
		if(unPoi.dentroDelRadio(unaInterface.latitud, unaInterface.longitud, 500)){
			return true;
		}
		return false;
	}
}

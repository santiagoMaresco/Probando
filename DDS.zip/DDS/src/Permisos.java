
public class Permisos {

}


public class RegistroDeBusqueda {
	String fraseBuscada;
	String terminal;
	String fecha;
	long tiempoDemorado;
	
	public void setFecha(String fecha){
		this.fecha = fecha;
	}
	
	public void setTerminal(String terminal){
		this.terminal = terminal;
	}
	public void setFraseBuscada(String frase){
		this.fraseBuscada = frase;
	}

	public void setTiempoDemorado(long tiempo){
		this.tiempoDemorado = tiempo;
	}

}

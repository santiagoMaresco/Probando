public class Banco extends Poi {

}
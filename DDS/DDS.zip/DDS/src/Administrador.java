
public class Administrador {

	public Mapa mapa;
}
